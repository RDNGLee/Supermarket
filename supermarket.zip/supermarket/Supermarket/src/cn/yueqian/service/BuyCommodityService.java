package cn.yueqian.service;

import cn.yueqian.bean.Employee;

public interface BuyCommodityService {
	void getAllSell_info();
	void addSell_info(Employee emp);
}
