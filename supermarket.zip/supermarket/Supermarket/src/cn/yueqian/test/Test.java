package cn.yueqian.test;

import java.math.BigDecimal;

import cn.yueqian.action.Login;

public class Test {
	public static void main(String[] args) throws Exception {
		Login login = new Login();
		login.login();
	}

}
